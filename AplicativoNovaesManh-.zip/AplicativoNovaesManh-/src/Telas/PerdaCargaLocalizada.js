import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Modal,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { MaterialIcons } from "@expo/vector-icons"; // Importação do ícone
import VoltarTela from "./VoltarTela";
import { StatusBar } from "react-native";

const { width, height } = Dimensions.get("window");

const PerdaCargaLocalizada = ({ navigation }) => {
  const [quantidade, setQuantidade] = useState("");
  const [coefPeca, setCoefPeca] = useState("");
  const [velocidade, setVelocidade] = useState("");
  const [result, setResult] = useState("");
  const [modalVisible, setModalVisible] = useState(false); // Estado para controlar a visibilidade do modal

  const calcularPerdaCarga = () => {
    // Adicione aqui o cálculo da perda de carga
    // Este espaço está intencionalmente em branco para você adicionar sua lógica de cálculo
    const g = 9.81;

    if(isNaN(quantidade) || isNaN(coefPeca) || isNaN(velocidade)){
        setResult("Insira os valores válidos");
    } else {
        const localizada = ((parseFloat(coefPeca) * parseFloat(quantidade)) * (parseFloat(velocidade) ** 2)) / (2 * g);
        setResult(localizada.toFixed(2) + " metros");
    }
  };

  const limparCampos = () => {
    setQuantidade("");
    setCoefPeca("");
    setVelocidade("");
    setResult("");
  };

  return (
    <LinearGradient colors={["#FFFFFF", "#FFFFFF"]} style={styles.gradient}>
      <View style={styles.container}>
        <StatusBar backgroundColor="#007B8F" barStyle="light-content" />
        <VoltarTela onPress={() => navigation.goBack()} />
        <Text style={styles.title}>Cálculo de Perda de Carga Localizada</Text>

        <TextInput
          style={[styles.input, styles.shadow]}
          onChangeText={text => setQuantidade(text)}
          value={quantidade}
          placeholder="Quantidade"
          keyboardType="numeric"
        />

        <TextInput
          style={[styles.input, styles.shadow]}
          onChangeText={text => setCoefPeca(text)}
          value={coefPeca}
          placeholder="Coeficiente da Peça"
          keyboardType="numeric"
        />

        <TextInput
          style={[styles.input, styles.shadow]}
          onChangeText={text => setVelocidade(text)}
          value={velocidade}
          placeholder="Velocidade (m/s)"
          keyboardType="numeric"
        />
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: "#53A176" }]}
            onPress={calcularPerdaCarga}
          >
            <Text style={styles.buttonText}>Calcular</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: "#FF0000" }]}
            onPress={limparCampos}
          >
            <Text style={styles.buttonText}>Limpar</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.result}>{result}</Text>

        {/* Botão de Informação */}
        <TouchableOpacity
          style={styles.infoButton}
          onPress={() => setModalVisible(true)}
        >
          <MaterialIcons name="info" size={24} color="black" />
        </TouchableOpacity>

        {/* Modal */}
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            setModalVisible(false);
          }}
        >
          <View style={styles.modalView}>
            <Text style={styles.modalText}>Seu texto informativo aqui...</Text>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => {
                setModalVisible(false);
              }}
            >
              <Text style={styles.closeButtonText}>Fechar</Text>
            </TouchableOpacity>
          </View>

        </Modal>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
    gradient: {
      flex: 1,
    },
    container: {
      justifyContent: "center",
      alignItems: "center",
      paddingHorizontal: width * 0.05,
      paddingVertical: height * 0.14,
      borderRadius: 15,
    },
    title: {
      marginLeft: 0,
      marginTop: height * 0.1,
      fontSize: width * 0.07,
      marginBottom: height * 0.03,
      fontFamily: "Montserrat-Bold",
    }, // Adicione essa chave de fechamento aqui
    input: {
      height: height * 0.07,
      width: width * 0.9,
      marginBottom: height * 0.03,
      paddingHorizontal: width * 0.04,
      backgroundColor: "#F3F3F3",
      borderRadius: 0,
      fontFamily: "Montserrat-Bold",
    },
    result: {
      marginTop: height * 0.02,
      fontSize: 16,
      fontFamily: "Montserrat-Regular",
    },
    buttonContainer: {
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      width: "100%",
    },
    button: {
      width: width * 0.45, // Ocupa 90% da largura da tela
      height: width * 0.1,
      justifyContent: "center",
      alignItems: "center",
      borderRadius: 11,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 1.0,
      shadowRadius: 3,
      elevation: 21,
    },
    buttonText: {
      color: "#FFFFFF",
      fontSize: 16,
      fontFamily: "Montserrat-Bold",
    },
    scrollViewContent: {
      flexGrow: 1,
      alignItems: "center",
    },
    shadow: {
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.2,
      shadowRadius: 2,
      elevation: 21,
    },
    infoButton: {
      position: "absolute",
      top: height * 0.2,
      right: width * 0.02,
      marginHorizontal: 14,
      marginVertical: 20,
    },
    modalView: {
      flex: 1,
      justifyContent: "center",
      alignItems: "center",
      backgroundColor: "rgba(0, 0, 0, 0.5)",
    },
    modalText: {
      backgroundColor: "white",
      padding: 20,
      borderRadius: 10,
      elevation: 5,
    },
    closeButton: {
      marginTop: 20,
      borderRadius: 20,
      padding: 10,
      elevation: 2,
    },
    closeButtonText: {
      color: "white",
      fontWeight: "bold",
      textAlign: "center",
    },
  });
  
  export default PerdaCargaLocalizada;
  